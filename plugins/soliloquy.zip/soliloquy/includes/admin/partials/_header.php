<?php $base = Soliloquy::get_instance(); ?>

<div id="soliloquy-header">

	<div id="soliloquy-logo"><img src="<?php echo plugins_url( 'assets/images/soliloquy-logo.png', $base->file  ); ?>" alt="<?php esc_html_e( 'Soliloquy', 'soliloquy'); ?>"></div>

</div>
